This zip file was downloaded on 2/20/2020 from

https://github.com/felis/USB_Host_Shield_2.0

A line was added to fix a problem with sensing read only status, 
see UsbHostShieldDiff.txt.